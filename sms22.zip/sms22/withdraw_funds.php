<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Withdraw Funds to Bank</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background: #f4f6f8;
      padding: 40px;
    }
    form {
      background: white;
      border-radius: 10px;
      padding: 30px;
      max-width: 500px;
      margin: auto;
      box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    }
    h2 { text-align: center; color: #333; }
    label { display: block; margin-bottom: 5px; }
    input, select {
      width: 100%;
      padding: 10px;
      margin-bottom: 15px;
      border-radius: 5px;
      border: 1px solid #ccc;
    }
    button {
      background: #007bff;
      color: white;
      border: none;
      padding: 10px;
      border-radius: 5px;
      width: 100%;
      cursor: pointer;
    }
    button:hover { background: #0056b3; }
  </style>
</head>
<body>
<p align="center">
<a href="index.php" 
   style="
      display:inline-block;
      padding:10px 20px;
      background:#007bff;
      color:#fff;
      font-weight:600;
      border-radius:8px;
      text-decoration:none;
      transition:0.3s;
   "
   onmouseover="this.style.background='#0056b3';"
   onmouseout="this.style.background='#007bff';"
>
   Home
</a> </p>
  <form action="process_withdraw.php" method="POST">
    <h2>Withdraw Funds to Bank</h2>
    <!-- Method field (fixed value) -->
    <input type="hidden" name="Method" value="acwithdrawfundstobank">

    <label for="amount">Amount:</label>
    <input type="number" name="Amount" id="amount" required>

    <label for="currency">Currency Code:</label>
    <select name="CurrencyCode" id="currency" required>
      <option value="">-- Select Currency --</option>
      <option value="UGX">UGX</option>
      <option value="USD">USD</option>
      <option value="EUR">EUR</option>
    </select>

    <label for="bank_account_name">Bank Account Name:</label>
    <input type="text" name="BankAccountName" id="bank_account_name" required>

    <label for="bank_account_number">Bank Account Number:</label>
    <input type="text" name="BankAccountNumber" id="bank_account_number" required>

   <label for="bank_account_identifier">Bank Account Identifier (Select Bank):</label>
<select name="BankAccountIdentifier" id="bank_account_identifier" required>
  <option value="">-- Select Bank --</option>
  <option value="ABC CAPITAL BANK UGANDA LIMITED">ABC CAPITAL BANK UGANDA LIMITED</option>
  <option value="ABSA BANK LIMITED UGANDA">ABSA BANK LIMITED UGANDA</option>
  <option value="BANK OF AFRICA UGANDA LIMITED">BANK OF AFRICA UGANDA LIMITED</option>
  <option value="BANK OF BARODA UGANDA LIMITED">BANK OF BARODA UGANDA LIMITED</option>
  <option value="BANK OF INDIA UGANDA LIMITED">BANK OF INDIA UGANDA LIMITED</option>
  <option value="BANK OF UGANDA">BANK OF UGANDA</option>
  <option value="CAIRO BANK UGANDA LIMITED">CAIRO BANK UGANDA LIMITED</option>
  <option value="CENTENARY RURAL DEVELOPMENT BANK LIMITED">CENTENARY RURAL DEVELOPMENT BANK LIMITED</option>
  <option value="CITIBANK UGANDA LIMITED">CITIBANK UGANDA LIMITED</option>
  <option value="DFCU BANK LIMITED">DFCU BANK LIMITED</option>
  <option value="DIAMOND TRUST BANK UGANDA LIMITED">DIAMOND TRUST BANK UGANDA LIMITED</option>
  <option value="ECOBANK UGANDA LIMITED">ECOBANK UGANDA LIMITED</option>
  <option value="EQUITY BANK UGANDA LIMITED">EQUITY BANK UGANDA LIMITED</option>
  <option value="EXIM BANK UGANDA LIMITED">EXIM BANK UGANDA LIMITED</option>
  <option value="FINANCE TRUST BANK LIMITED">FINANCE TRUST BANK LIMITED</option>
  <option value="GUARANTY TRUST BANK UGANDA LIMITED">GUARANTY TRUST BANK UGANDA LIMITED</option>
  <option value="HOUSING FINANCE BANK UGANDA LIMITED">HOUSING FINANCE BANK UGANDA LIMITED</option>
  <option value="I&M BANK UGANDA LIMITED">I&M BANK UGANDA LIMITED</option>
  <option value="KCB BANK UGANDA LIMITED">KCB BANK UGANDA LIMITED</option>
  <option value="NCBA BANK UGANDA LIMITED">NCBA BANK UGANDA LIMITED</option>
  <option value="OPPORTUNITY BANK UGANDA LIMITED">OPPORTUNITY BANK UGANDA LIMITED</option>
  <option value="POST BANK UGANDA LIMITED">POST BANK UGANDA LIMITED</option>
  <option value="STANBIC BANK UGANDA LIMITED">STANBIC BANK UGANDA LIMITED</option>
  <option value="STANDARD CHARTERED BANK UGANDA LIMITED">STANDARD CHARTERED BANK UGANDA LIMITED</option>
  <option value="TROPICAL BANK UGANDA LIMITED">TROPICAL BANK UGANDA LIMITED</option>
  <option value="UNITED BANK FOR AFRICA UGANDA LIMITED">UNITED BANK FOR AFRICA UGANDA LIMITED</option>
</select>

    <label for="private_reference">Private Transaction Reference:</label>
    <input type="text" name="PrivateTransactionReference" id="private_reference" placeholder="Internal Reference or Memo" required>

    <button type="submit">Withdraw Now</button>
  </form>

</body>
</html>
