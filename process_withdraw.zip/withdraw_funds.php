<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Withdraw Funds</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background: #f4f6f8;
      padding: 40px;
    }
    form {
      background: white;
      border-radius: 10px;
      padding: 30px;
      max-width: 500px;
      margin: auto;
      box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    }
    h2 { text-align: center; color: #333; }
    label { display: block; margin-bottom: 5px; }
    input, select {
      width: 100%;
      padding: 10px;
      margin-bottom: 15px;
      border-radius: 5px;
      border: 1px solid #ccc;
    }
    button {
      background: #007bff;
      color: white;
      border: none;
      padding: 10px;
      border-radius: 5px;
      width: 100%;
      cursor: pointer;
    }
    button:hover { background: #0056b3; }
  </style>
</head>
<body>

  <form action="process_withdraw.php" method="POST">
    <h2>Withdraw Funds</h2>

    <!-- API Credentials -->
    <input type="hidden" name="Method" value="acwithdrawfunds">

    <label for="nonblocking">Non-Blocking:</label>
    <select name="NonBlocking" id="nonblocking">
      <option value="">-- Select --</option>
      <option value="true">Yes</option>
      <option value="false">No</option>
    </select>

    <label for="amount">Amount (UGX):</label>
    <input type="number" name="Amount" id="amount" required>

    <label for="account">Account Number:</label>
    <input type="text" name="Account" id="account" required>

    <label for="provider">Account Provider Code:</label>
    <select name="AccountProviderCode" id="provider" required>
      <option value="">-- Select Provider --</option>
      <option value="MTN_UGANDA">MTN Uganda</option>
      <option value="AIRTEL_UGANDA">Airtel Uganda</option>
    </select>

    <label for="transaction_limit">Transaction Limit Account Identifier:</label>
    <input type="text" name="TransactionLimitAccountIdentifier" id="transaction_limit">

    <label for="narrative">Narrative:</label>
    <input type="text" name="Narrative" id="narrative" placeholder="Payment description" required>

    <label for="narrative_file_name">Narrative File Name:</label>
    <input type="text" name="NarrativeFileName" id="narrative_file_name">

    <label for="narrative_file_base64">Narrative File (Base64):</label>
    <input type="text" name="NarrativeFileBase64" id="narrative_file_base64">

    <label for="internal_ref">Internal Reference:</label>
    <input type="text" name="InternalReference" id="internal_ref">

    <label for="external_ref">External Reference:</label>
    <input type="text" name="ExternalReference" id="external_ref">

    <label for="provider_ref">Provider Reference Text:</label>
    <input type="text" name="ProviderReferenceText" id="provider_ref">
    <button type="submit">Withdraw Now</button>
  </form>

</body>
</html>
