<?php
// momo_integration.php
// Simple MTN MoMo Collections (Request-to-Pay) flow in PHP (cURL).
// Replace placeholders before use.

// CONFIG
define('ENVIRONMENT', 'sandbox'); // 'sandbox' or 'production'
define('SUBSCRIPTION_KEY', 'XXX_YOUR_SUBSCRIPTION_KEY_XXX'); // Ocp-Apim-Subscription-Key
define('API_USER', 'XXX_YOUR_API_USER_UUID_XXX'); // API user UUID created in portal
define('API_KEY', 'XXX_YOUR_API_KEY_XXX'); // API user key (the secret for API user)
define('CALLBACK_URL', 'https://yourdomain.com/momo_callback.php'); // Your callback endpoint

// Base URLs (sandbox urls per MoMo docs). Use production host when ready.
$baseUrls = [
    'sandbox' => 'https://sandbox.momodeveloper.mtn.com',
    'production' => 'https://api.mtn.com'
];
$base = $baseUrls[ENVIRONMENT];

/**
 * Get OAuth access token (Bearer) for subsequent requests.
 * The MoMo OAuth endpoint expects Basic auth using API_USER:API_KEY (Base64) and
 * the header Ocp-Apim-Subscription-Key.
 */
function getAccessToken($base) {
    $tokenEndpoint = $base . '/collection/v1_0/token/'; // Note: some docs use /oauth/token or /collection/v1_0/token/
    $ch = curl_init($tokenEndpoint);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    // Basic auth header using API_USER and API_KEY
    $auth = base64_encode(API_USER . ':' . API_KEY);
    $headers = [
        "Authorization: Basic {$auth}",
        "Ocp-Apim-Subscription-Key: " . SUBSCRIPTION_KEY,
        "Content-Type: application/json"
    ];
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_POSTFIELDS, "{}"); // some sandboxes require a POST body
    $resp = curl_exec($ch);
    if ($resp === false) {
        throw new Exception('Token request failed: ' . curl_error($ch));
    }
    $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    $data = json_decode($resp, true);
    if ($httpcode >= 200 && $httpcode < 300 && isset($data['access_token'])) {
        return $data['access_token'];
    }
    // Some MTN sandboxes return {"access_token":"...","token_type":"Bearer","expires_in":"3600"}
    if (isset($data['token'])) {
        return $data['token'];
    }
    throw new Exception('Could not obtain access token. HTTP ' . $httpcode . ' Response: ' . $resp);
}

/**
 * Initiate Request To Pay (collection)
 * $amount = decimal string (e.g. "10.00"), $msisdn = customer phone in international format (e.g. 2567XXXXXXXX),
 * $payerMessage and $payeeNote optional.
 */
function requestToPay($base, $accessToken, $amount, $msisdn, $currency = 'EUR', $payerMessage = 'Payment', $payeeNote = '') {
    // Use currency and formats as required by your country settings. For Uganda use 'UGX', Ghana 'GHS', etc.
    $url = $base . '/collection/v1_0/requesttopay';
    // X-Reference-Id must be a UUID (unique per request)
    $referenceId = guidv4();
    $body = [
        'amount' => (string)$amount,
        'currency' => $currency,
        'externalId' => time(), // or your internal invoice id
        'payer' => [
            'partyIdType' => 'MSISDN',
            'partyId' => $msisdn
        ],
        'payerMessage' => $payerMessage,
        'payeeNote' => $payeeNote,
        'callbackUrl' => CALLBACK_URL
    ];
    $ch = curl_init($url);
    $headers = [
        "Authorization: Bearer {$accessToken}",
        "X-Reference-Id: {$referenceId}",
        "X-Target-Environment: " . (ENVIRONMENT === 'sandbox' ? 'sandbox' : 'production'),
        "Ocp-Apim-Subscription-Key: " . SUBSCRIPTION_KEY,
        "Content-Type: application/json"
    ];
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $resp = curl_exec($ch);
    $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    // Typically the API returns 202 Accepted with empty body for request-to-pay initiation
    if ($httpcode == 202) {
        return ['status' => 'accepted', 'referenceId' => $referenceId];
    }
    return ['status' => 'error', 'httpcode' => $httpcode, 'response' => $resp];
}

/**
 * Check status of a Request-to-Pay
 */
function checkRequestStatus($base, $accessToken, $referenceId) {
    $url = $base . "/collection/v1_0/requesttopay/{$referenceId}";
    $ch = curl_init($url);
    $headers = [
        "Authorization: Bearer {$accessToken}",
        "X-Target-Environment: " . (ENVIRONMENT === 'sandbox' ? 'sandbox' : 'production'),
        "Ocp-Apim-Subscription-Key: " . SUBSCRIPTION_KEY,
        "Content-Type: application/json"
    ];
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $resp = curl_exec($ch);
    if ($resp === false) {
        throw new Exception('Status check failed: ' . curl_error($ch));
    }
    $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    $data = json_decode($resp, true);
    return ['httpcode' => $httpcode, 'response' => $data];
}

/**
 * UUID v4 generator for X-Reference-Id (simple)
 */
function guidv4() {
    if (function_exists('com_create_guid') === true) {
        return trim(com_create_guid(), '{}');
    }
    $data = openssl_random_pseudo_bytes(16);
    $data[6] = chr((ord($data[6]) & 0x0f) | 0x40);
    $data[8] = chr((ord($data[8]) & 0x3f) | 0x80);
    return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($data), 4));
}

/*
 * Example usage:
 */
try {
    $token = getAccessToken($base);
    // Initiate request to pay 5.00 (change currency to your country code; e.g. 'UGX' for Uganda)
    $init = requestToPay($base, $token, "5.00", "25677XXXXXXX", "UGX", "Invoice #1234", "Thanks for your purchase");
    if ($init['status'] === 'accepted') {
        echo "Request accepted. ReferenceId: " . $init['referenceId'] . PHP_EOL;
        // Optionally poll the status (or wait for callback)
        sleep(4); // small delay before checking
        $status = checkRequestStatus($base, $token, $init['referenceId']);
        var_dump($status);
    } else {
        echo "Request failed: " . json_encode($init) . PHP_EOL;
    }
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . PHP_EOL;
}
