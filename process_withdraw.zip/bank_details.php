<?php
// bank_details.php

// === INCLUDE FILES (if neeinclude 'signnn2.php';
include 'collect_data.php';

// === CONFIGURATION ===
$api_url = "https://paymentsapi1.yo.co.ug/ybs/task.php";  // Replace with actual API endpoint
$api_user = "100615770361";  // Replace with your real username
$api_pass = "Tdww-wvR3-ECQ8-gPbZ-Ai3u-VQ7n-3TFU-2bPm";   // Replace with your real password

// === COLLECT POST VALUES FROM FORM ===
$BankName     = trim($_POST['BankName'] ?? '');
$Street1      = trim($_POST['StreetAddressLine1'] ?? '');
$Street2      = trim($_POST['StreetAddressLine2'] ?? '');
$City         = trim($_POST['City'] ?? '');
$State        = trim($_POST['State'] ?? '');
$Country      = trim($_POST['Country'] ?? '');

$AccountName  = trim($_POST['AccountName'] ?? '');
$AccountNumber = trim($_POST['AccountNumber'] ?? '');


// === BUILD XML REQUEST ===
$xmlRequest = <<<XML
<?xml version="1.0" encoding="UTF-8"?>
<AutoCreate>
  <Request>
    <APIUsername>{$api_user}</APIUsername>
    <APIPassword>{$api_pass}</APIPassword>
    <Method>accreateverifiedbankaccount</Method>
    <AccountName>{$AccountName}</AccountName>
    <AccountNumber>{$AccountNumber}</AccountNumber>
    <BankInformation>
      <Name>{$BankName}</Name>
      <StreetAddressLine1>{$Street1}</StreetAddressLine1>
      <StreetAddressLine2>{$Street2}</StreetAddressLine2>
      <City>{$City}</City>
      <State>{$State}</State>
      <Country>{$Country}</Country>
  </Request>
</AutoCreate>
XML;
?>
<?php
// === SEND XML VIA CURL ===
$ch = curl_init($api_url);
curl_setopt_array($ch, [
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => $xmlRequest,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_HTTPHEADER => [
        "Content-Type: application/xml",
        "Accept: application/xml"
    ],
    CURLOPT_TIMEOUT => 30,
    CURLOPT_SSL_VERIFYPEER => false,
    CURLOPT_SSL_VERIFYHOST => false
]);

$response = curl_exec($ch);
if (curl_errno($ch)) {
    $error = curl_error($ch);
    curl_close($ch);
    die("<h3 style='color:red'>Connection error:</h3><pre>$error</pre>");
}
curl_close($ch);

// === DISPLAY XML REQUEST & RESPONSE (for testing) ===
header("Content-Type: text/html; charset=UTF-8");
echo "<h2>XML Sent:</h2>";
echo "<pre>" . htmlspecialchars($xmlRequest) . "</pre>";

echo "<h2>Response Received:</h2>";
echo "<pre>" . htmlspecialchars($response) . "</pre>";

// === OPTIONAL: PARSE RESPONSE ===
$xmlResponse = @simplexml_load_string($response);
if ($xmlResponse === false) {
    echo "<p style='color:red'>Invalid XML response received from API.</p>";
} else {
    echo "<h3>Parsed Response:</h3><pre>";
    print_r($xmlResponse);
    echo "</pre>";
}
?>
