<?php
require_once 'connect.php';

$data = json_decode(file_get_contents('php://input'), true);

$referenceId = $data['referenceId'] ?? '';
$status = $data['status'] ?? '';
$amount = $data['amount'] ?? '';
$phone = $data['payer']['partyId'] ?? '';

if ($referenceId && $status) {
    mysqli_query($conn, "UPDATE momo_payments SET status='$status' WHERE reference_id='$referenceId'");

    if ($status == 'SUCCESSFUL') {
        // Optionally, update booking as paid
        mysqli_query($conn, "UPDATE bookings 
                             SET payment_status='PAID' 
                             WHERE id=(SELECT booking_id FROM momo_payments WHERE reference_id='$referenceId')");
    }
}

// Always respond 200
http_response_code(200);
echo json_encode(['message' => 'Callback received']);

?>