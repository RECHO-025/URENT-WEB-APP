<?php
// process_withdraw.php
header("Content-Type: text/html; charset=UTF-8");

// === Yo! Payments API credentials ===
$api_url  = "https://paymentsapi1.yo.co.ug/ybs/task.php"; 
$api_user = "100615770361";  // Replace with your actual API Username
$api_pass = "Tdww-wvR3-ECQ8-gPbZ-Ai3u-VQ7n-3TFU-2bPm"; // Replace with your actual API Password

// === Collect form data safely ===
$Amount                   = trim($_POST['Amount'] ?? '');
$CurrencyCode             = trim($_POST['CurrencyCode'] ?? '');
$BankAccountName          = trim($_POST['BankAccountName'] ?? '');
$BankAccountNumber        = trim($_POST['BankAccountNumber'] ?? '');
$BankAccountIdentifier    = trim($_POST['BankAccountIdentifier'] ?? '');
$TransferTransactionType  = trim($_POST['TransferTransactionType'] ?? '');
$PrivateTransactionReference = trim($_POST['PrivateTransactionReference'] ?? '');

// === Build XML request ===
$xmlRequest = <<<XML
<?xml version="1.0" encoding="UTF-8"?>
<AutoCreate>
  <Request>
    <APIUsername>{$api_user}</APIUsername>
    <APIPassword>{$api_pass}</APIPassword>
    <Method>acwithdrawfundstobank</Method>
    <Amount>{$Amount}</Amount>
    <CurrencyCode>{$CurrencyCode}</CurrencyCode>
    <BankAccountName>{$BankAccountName}</BankAccountName>
    <BankAccountNumber>{$BankAccountNumber}</BankAccountNumber>
    <BankAccountIdentifier>{$BankAccountIdentifier}</BankAccountIdentifier>
    <PrivateTransactionReference>{$PrivateTransactionReference}</PrivateTransactionReference>
  </Request>
</AutoCreate>
XML;
?>
<?php
// === Send XML to API using cURL ===
$ch = curl_init($api_url);
curl_setopt_array($ch, [
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => $xmlRequest,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_HTTPHEADER => [
        "Content-Type: application/xml",
        "Accept: application/xml"
    ],
    CURLOPT_TIMEOUT => 60,
    CURLOPT_SSL_VERIFYPEER => false,
    CURLOPT_SSL_VERIFYHOST => false
]);

$response = curl_exec($ch);

if (curl_errno($ch)) {
    $error = curl_error($ch);
    curl_close($ch);
    die("<h3 style='color:red;'>Connection error:</h3><pre>$error</pre>");
}

curl_close($ch);

// === Display request and response ===
echo "<h2>XML Sent:</h2><pre>" . htmlspecialchars($xmlRequest) . "</pre>";
echo "<h2>Response Received:</h2><pre>" . htmlspecialchars($response) . "</pre>";

// === Parse XML response (optional) ===
$xmlResponse = @simplexml_load_string($response);
if ($xmlResponse === false) {
    echo "<p style='color:red;'>Invalid XML response received.</p>";
} else {
    echo "<h3>Parsed Response:</h3><pre>";
    print_r($xmlResponse);
    echo "</pre>";
}
?>
