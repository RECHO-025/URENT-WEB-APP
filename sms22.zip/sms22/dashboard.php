<?php
session_start();

// Redirect if not logged in
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header('Location: login.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Admin Dashboard | Rent Management System</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
      background: linear-gradient(135deg, #e0f2ff, #ffffff);
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      color: #333;
    }
    .container {
      text-align: center;
      background: #fff;
      padding: 40px 30px;
      border-radius: 16px;
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
      width: 95%;
      max-width: 900px;
      position: relative;
    }
    h1 { color: #0066cc; margin-bottom: 10px; font-size: 28px; }
    h2 {
      margin-top: 30px;
      margin-bottom: 15px;
      font-size: 20px;
      color: #444;
      border-bottom: 2px solid #e0e0e0;
      padding-bottom: 8px;
    }
    p { margin: 10px 0 25px; font-size: 15px; color: #555; }
    .grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
      gap: 20px;
      margin-top: 10px;
    }
    a {
      text-decoration: none;
      color: #fff;
      font-weight: 600;
      padding: 14px 10px;
      border-radius: 10px;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      gap: 10px;
      transition: all 0.3s ease;
      box-shadow: 0 3px 6px rgba(0, 123, 255, 0.2);
    }
    a svg { width: 45px; height: 45px; }
    a:hover {
      transform: translateY(-3px);
      box-shadow: 0 6px 14px rgba(0, 0, 0, 0.2);
    }
    .logout {
      position: absolute;
      top: 15px;
      right: 15px;
      background: #dc3545;
      color: #fff;
      padding: 8px 14px;
      border-radius: 6px;
      font-size: 14px;
      text-decoration: none;
      transition: 0.3s;
    }
    .logout:hover {
      background: #b52a38;
      box-shadow: 0 3px 10px rgba(220, 53, 69, 0.3);
    }
    footer {
      margin-top: 35px;
      font-size: 14px;
      color: #888;
    }
  </style>
</head>
<body>

<div class="container">
  <a href="logout.php" class="logout">Logout</a>

  <h1>Welcome, <?= htmlspecialchars($_SESSION['username']) ?>!</h1>
  <p>System Administrator Dashboard – Manage Landlords, Subscriptions, and Bank Operations.</p>

  <!-- Rent & Landlord Management Section -->
  <h2>Rent & Landlord Management</h2>
  <div class="grid">
    <a href="manage_landlords.php" style="background:#007bff;">
      <svg xmlns="http://www.w3.org/2000/svg" fill="none" stroke="#fff" viewBox="0 0 64 64" stroke-width="1.5">
        <circle cx="32" cy="20" r="12"/><path d="M8 56c0-10.667 8-20 24-20s24 9.333 24 20"/>
      </svg>
      Manage Landlords
    </a>

    <a href="add_landlord.php" style="background:#28a745;">
      <svg xmlns="http://www.w3.org/2000/svg" fill="none" stroke="#fff" viewBox="0 0 64 64" stroke-width="1.5">
        <path d="M32 8v48M8 32h48"/>
      </svg>
      Add New Landlord
    </a>

    <a href="renew_subscription.php" style="background:#17a2b8;">
      <svg xmlns="http://www.w3.org/2000/svg" fill="none" stroke="#fff" viewBox="0 0 64 64" stroke-width="1.5">
        <path d="M32 8a24 24 0 1 0 24 24h-8M32 8v8"/>
      </svg>
      Renew Subscription
    </a>

    <a href="account_status.php" style="background:#dc3545;">
      <svg xmlns="http://www.w3.org/2000/svg" fill="none" stroke="#fff" viewBox="0 0 64 64" stroke-width="1.5">
        <circle cx="32" cy="32" r="24"/><path d="M32 20v12l8 8"/>
      </svg>
      Account Status
    </a>

    <a href="reports.php" style="background:#6c757d;">
      <svg xmlns="http://www.w3.org/2000/svg" fill="none" stroke="#fff" viewBox="0 0 64 64" stroke-width="1.5">
        <path d="M8 8h48v48H8zM16 40h8V24h-8v16zm12 0h8V16h-8v24zm12 0h8V32h-8v8z"/>
      </svg>
      Reports
    </a>

    <a href="settings.php" style="background:#343a40;">
      <svg xmlns="http://www.w3.org/2000/svg" fill="none" stroke="#fff" viewBox="0 0 64 64" stroke-width="1.5">
        <circle cx="32" cy="32" r="8"/>
        <path d="M32 8v8M32 48v8M8 32h8M48 32h8M14 14l6 6M44 44l6 6M14 50l6-6M44 20l6-6"/>
      </svg>
      Settings
    </a>
  </div>

  <!-- Bank Operations Section -->
  <h2>Bank Operations</h2>
  <div class="grid">
    <a href="withdraw_funds.php" style="background:#007bff;">
      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 64 64" stroke-width="1.5" stroke="#fff">
        <path d="M32 4v56M20 44l12 12 12-12M12 20h40M8 12h48v8H8z"/>
      </svg>
      Withdraw Funds
    </a>

    <a href="autocreate_form.html" style="background:#28a745;">
      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 64 64" stroke-width="1.5" stroke="#fff">
        <path d="M8 24l24-16 24 16v24H8V24z"/>
        <path d="M16 32h32M16 40h32M16 48h32"/>
      </svg>
      Bank Register
    </a>

    <a href="bank_deposit_form.html" style="background:#ff9800;">
      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 64 64" stroke-width="1.5" stroke="#fff">
        <path d="M32 8L8 20v24l24 12 24-12V20L32 8z"/>
        <path d="M24 28h16v8H24zM16 40h32"/>
      </svg>
      Bank Deposit
    </a>
  </div>

  <footer>© 2025 Rent & Estate Management System</footer>
</div>

</body>
</html>
