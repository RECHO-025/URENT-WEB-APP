<?php

$servername = "localhost";
$username1 = "eljotellug_sms";
$password = "0702014626@Bjk";
$dbname = "eljotellug_sms";

$username2 = "eljotellug_jotell";
$password2 = "0702014626@Bjk";
$dbname2 = "eljotellug_jotell";

// Create connection
$conn = new mysqli($servername, $username1, $password, $dbname);

$conn2 = new mysqli($servername, $username2, $password2, $dbname2);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
} 
 
if ($conn2->connect_error) {
  die("Connection failed: " . $conn2->connect_error);
} 
   
  
  ?>