<?php
// momo/momo_config.php

// Environment: use 'sandbox' for testing, switch to 'production' when going live
define('ENVIRONMENT', 'sandbox');

// Your MoMo Collection API subscription key (from MTN developer portal)
define('SUBSCRIPTION_KEY', '5a65209453a34aa390051818b54096ac');

// This is your registered MoMo API User (usually generated as a UUID)
define('API_USER', 'Urent');

// Your Primary API Key (keep this secret!)
define('API_KEY', '5a65209453a34aa390051818b54096ac');

// The URL MTN will call after a transaction completes
// Update this to your actual domain when you go live
define('CALLBACK_URL', 'https://yourdomain.com/momo/momo_callback.php');

// Currency for Uganda
define('CURRENCY', 'UGX');
?>
