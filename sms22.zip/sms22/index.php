<?php
session_start();

require __DIR__ . '/vendor/autoload.php'; // Composer autoload

use PragmaRX\Google2FA\Google2FA;

// Redirect logged-in users
if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true) {
    header('Location: dashboard.php');
    exit;
}

// Database connection
$host = 'localhost';
$dbname = 'paymentgateway';
$dbuser = 'root';
$dbpass = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $dbuser, $dbpass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

$login_error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');
    $code     = trim($_POST['code'] ?? '');

    // Fetch user from database
    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->execute([$username]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user && password_verify($password, $user['password'])) {
        // Verify Google2FA code
        $google2fa = new Google2FA();
        if ($google2fa->verifyKey($user['google_secret'], $code)) {
            $_SESSION['loggedin'] = true;
            $_SESSION['username'] = $user['username'];
            header('Location: dashboard.php');
            exit;
        } else {
            $login_error = 'Invalid Google Authenticator code.';
        }
    } else {
        $login_error = 'Invalid username or password.';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Login | MySmS Payment Portal</title>
<style>
body { font-family:"Segoe UI", sans-serif; background:linear-gradient(135deg,#e0f2ff,#fff); display:flex; justify-content:center; align-items:center; height:100vh; }
.login-container { background:#fff; padding:30px 40px; border-radius:16px; box-shadow:0 4px 20px rgba(0,0,0,0.1); width:100%; max-width:400px; text-align:center; }
h2 { color:#0066cc; margin-bottom:20px; }
input { width:100%; padding:12px; margin:10px 0; border-radius:8px; border:1px solid #ccc; }
button { width:100%; padding:12px; border:none; border-radius:8px; background:#007bff; color:#fff; font-weight:600; cursor:pointer; transition:0.3s; }
button:hover { background:#0056b3; }
.error { color:red; margin-bottom:10px; }
</style>
</head>
<body>


<div class="login-container">
    <h2>Login to Payment Management System</h2>
    <?php if($login_error): ?>
        <div class="error"><?=htmlspecialchars($login_error)?></div>
    <?php endif; ?>
    <form method="POST">
        <input type="text" name="username" placeholder="Username" required>
        <input type="password" name="password" placeholder="Password" required>
        <input type="text" name="code" placeholder="Google Authenticator Code" required>
        <button type="submit">Login</button>
    </form>
</div>

<p align="center">  
<a href="pay.php" class="pay-btn">Pay with MoMo</a>
 </p>

</body>
</html>
