<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>MySmS | Payment Portal</title>
  <style>
    /* ===== Reset & Base Styles ===== */
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }

    body {
      font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
      background: linear-gradient(135deg, #e0f2ff, #ffffff);
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      color: #333;
    }

    .container {
      text-align: center;
      background: #fff;
      padding: 40px 30px;
      border-radius: 16px;
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
      width: 90%;
      max-width: 500px;
    }

    h1 {
      color: #0066cc;
      margin-bottom: 25px;
      font-size: 28px;
    }

    p {
      margin: 20px 0;
    }

    a {
      text-decoration: none;
      color: #fff;
      font-weight: 600;
      background: #007bff;
      padding: 12px 24px;
      border-radius: 8px;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      gap: 10px;
      transition: all 0.3s ease;
      box-shadow: 0 3px 6px rgba(0, 123, 255, 0.2);
    }

    a:hover {
      background: #0056b3;
      box-shadow: 0 4px 12px rgba(0, 123, 255, 0.3);
      transform: translateY(-2px);
    }

    .illustration {
      width: 80px;
      height: 80px;
      margin: 10px auto 15px;
    }

    footer {
      margin-top: 30px;
      font-size: 14px;
      color: #888;
    }
  </style>
</head>
<body>

  <div class="container">
    <h1>?? MySmS Payment Dashboard</h1>
    <p>Manage your bank-related operations securely and conveniently.</p>

    <div>
      <div class="illustration">
        <!-- Withdraw Icon -->
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 64 64" stroke-width="1.5" stroke="#007bff">
          <path d="M32 4v56M20 44l12 12 12-12M12 20h40M8 12h48v8H8z"/>
        </svg>
      </div>
      <p><a href="withdraw_funds.php">Withdraw Funds</a></p>

      <div class="illustration">
        <!-- Bank Register Icon -->
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 64 64" stroke-width="1.5" stroke="#28a745">
          <path d="M8 24l24-16 24 16v24H8V24z"/>
          <path d="M16 32h32M16 40h32M16 48h32"/>
        </svg>
      </div>
      <p><a href="autocreate_form.html" style="background:#28a745;">Bank Register</a></p>

      <div class="illustration">
        <!-- Bank Deposit Icon -->
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 64 64" stroke-width="1.5" stroke="#ff9800">
          <path d="M32 8L8 20v24l24 12 24-12V20L32 8z"/>
          <path d="M24 28h16v8H24zM16 40h32"/>
        </svg>
      </div>
      <p><a href="bank_deposit_form.html" style="background:#ff9800;">Bank Deposit</a></p>
    </div>

    <footer>� 2025 MySmS Payment System</footer>
  </div>

</body>
</html>
