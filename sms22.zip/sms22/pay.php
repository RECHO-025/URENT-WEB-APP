<form id="momoForm">
  <input type="hidden" name="booking_id" value="BKG123">
  <label>Enter MoMo Number:</label><br>
  <input type="text" name="phone" placeholder="2567XXXXXXX" required><br><br>
  <label>Amount (UGX):</label><br>
  <input type="number" name="amount" value="50000" readonly><br><br>
  <button type="submit">Pay with MTN MoMo</button>
</form>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$('#momoForm').on('submit', function(e) {
  e.preventDefault();

  const formData = $(this).serialize();
  console.log('Sending data:', formData);

  $.ajax({
    url: 'momo_request.php',  // ? Correct relative path
    type: 'POST',
    data: formData,
    dataType: 'json',
    success: function(resp) {
      console.log('Server response:', resp);
      if (resp.status_code === 202) {
        alert('? Payment initiated! Check your phone to approve the transaction.');
      } else {
        alert('?? Payment initiation failed. See console for details.');
      }
    },
    error: function(xhr, status, error) {
      console.error('AJAX error:', error);
      console.log('Response text:', xhr.responseText);
      alert('? Something went wrong. Check browser console.');
    }
  });
});
</script>
