<?php
// withdraw_funds.php
header("Content-Type: text/html; charset=UTF-8");

// === YoPayments credentials ===
$api_url  = "https://paymentsapi1.yo.co.ug/ybs/task.php"; // Replace with your actual API endpoint
$api_user = "100615770361";  // Replace with your real API Username
$api_pass = "Tdww-wvR3-ECQ8-gPbZ-Ai3u-VQ7n-3TFU-2bPm";   // Replace with your real API Password

// === COLLECT FORM DATA ===
$Amount                           = trim($_POST['Amount'] ?? '');
$Account                          = trim($_POST['Account'] ?? '');
$AccountProviderCode               = trim($_POST['AccountProviderCode'] ?? '');
$NonBlocking                       = trim($_POST['NonBlocking'] ?? '');
$TransactionLimitAccountIdentifier = trim($_POST['TransactionLimitAccountIdentifier'] ?? '');
$Narrative                         = trim($_POST['Narrative'] ?? '');
$NarrativeFileName                 = trim($_POST['NarrativeFileName'] ?? '');
$NarrativeFileBase64               = trim($_POST['NarrativeFileBase64'] ?? '');
$InternalReference                 = trim($_POST['InternalReference'] ?? '');
$ExternalReference                 = trim($_POST['ExternalReference'] ?? '');
$ProviderReferenceText             = trim($_POST['ProviderReferenceText'] ?? '');
$PublicKeyAuthenticationNonce      = trim($_POST['PublicKeyAuthenticationNonce'] ?? '');
$PublicKeyAuthenticationSignatureBase64 = trim($_POST['PublicKeyAuthenticationSignatureBase64'] ?? '');

// === BUILD XML REQUEST ===
$xmlRequest = <<<XML
<?xml version="1.0" encoding="UTF-8"?>
<AutoCreate>
  <Request>
    <APIUsername>{$api_user}</APIUsername>
    <APIPassword>{$api_pass}</APIPassword>
    <Method>acwithdrawfunds</Method>
    <NonBlocking>{$NonBlocking}</NonBlocking>
    <Amount>{$Amount}</Amount>
    <Account>{$Account}</Account>
    <AccountProviderCode>{$AccountProviderCode}</AccountProviderCode>
    <TransactionLimitAccountIdentifier>{$TransactionLimitAccountIdentifier}</TransactionLimitAccountIdentifier>
    <Narrative>{$Narrative}</Narrative>
    <NarrativeFileName>{$NarrativeFileName}</NarrativeFileName>
    <NarrativeFileBase64>{$NarrativeFileBase64}</NarrativeFileBase64>
    <InternalReference>{$InternalReference}</InternalReference>
    <ExternalReference>{$ExternalReference}</ExternalReference>
    <ProviderReferenceText>{$ProviderReferenceText}</ProviderReferenceText>
    <PublicKeyAuthenticationNonce>{$PublicKeyAuthenticationNonce}</PublicKeyAuthenticationNonce>
    <PublicKeyAuthenticationSignatureBase64>{$PublicKeyAuthenticationSignatureBase64}</PublicKeyAuthenticationSignatureBase64>
  </Request>
</AutoCreate>
XML;
?>
<?php
// === SEND XML VIA CURL ===
$ch = curl_init($api_url);
curl_setopt_array($ch, [
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => $xmlRequest,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_HTTPHEADER => [
        "Content-Type: application/xml",
        "Accept: application/xml"
    ],
    CURLOPT_TIMEOUT => 60,
    CURLOPT_SSL_VERIFYPEER => false,
    CURLOPT_SSL_VERIFYHOST => false
]);

$response = curl_exec($ch);
if (curl_errno($ch)) {
    $error = curl_error($ch);
    curl_close($ch);
    die("<h3 style='color:red;'>Connection error:</h3><pre>$error</pre>");
}
curl_close($ch);

// === DISPLAY REQUEST & RESPONSE ===
echo "<h2>XML Sent:</h2><pre>" . htmlspecialchars($xmlRequest) . "</pre>";
echo "<h2>Response Received:</h2><pre>" . htmlspecialchars($response) . "</pre>";

// === PARSE RESPONSE (Optional) ===
$xmlResponse = @simplexml_load_string($response);
if ($xmlResponse === false) {
    echo "<p style='color:red;'>Invalid XML response received.</p>";
} else {
    echo "<h3>Parsed Response:</h3><pre>";
    print_r($xmlResponse);
    echo "</pre>";
}
?>
