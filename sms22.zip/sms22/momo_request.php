<?php
require_once 'momo_config.php';
require_once 'connect.php'; // your database connection

function getAccessToken($base) {
    $url = $base . '/collection/token/';
    $auth = base64_encode(API_USER . ':' . API_KEY);

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_HTTPHEADER => [
            "Authorization: Basic $auth",
            "Ocp-Apim-Subscription-Key: " . SUBSCRIPTION_KEY,
        ],
    ]);
    $response = curl_exec($ch);
    $data = json_decode($response, true);
    curl_close($ch);

    return $data['access_token'] ?? null;
}

function guidv4() {
    $data = openssl_random_pseudo_bytes(16);
    $data[6] = chr((ord($data[6]) & 0x0f) | 0x40);
    $data[8] = chr((ord($data[8]) & 0x3f) | 0x80);
    return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($data), 4));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $phone = $_POST['phone'];
    $amount = $_POST['amount'];
    $bookingId = $_POST['booking_id'];

    $base = (ENVIRONMENT === 'sandbox') ? 'https://sandbox.momodeveloper.mtn.com' : 'https://api.mtn.com';
    $token = getAccessToken($base);
    $referenceId = guidv4();

    $payload = [
        'amount' => $amount,
        'currency' => CURRENCY,
        'externalId' => $bookingId,
        'payer' => ['partyIdType' => 'MSISDN', 'partyId' => $phone],
        'payerMessage' => 'Urent Deposit',
        'payeeNote' => 'Vehicle Booking Deposit',
    ];

    $ch = curl_init("$base/collection/v1_0/requesttopay");
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_HTTPHEADER => [
            "Authorization: Bearer $token",
            "X-Reference-Id: $referenceId",
            "X-Target-Environment: sandbox",
            "Ocp-Apim-Subscription-Key: " . SUBSCRIPTION_KEY,
            "Content-Type: application/json",
        ],
        CURLOPT_POSTFIELDS => json_encode($payload),
    ]);

    $response = curl_exec($ch);
    $status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    // Save request to DB for tracking
    mysqli_query($conn, "INSERT INTO momo_payments (booking_id, reference_id, phone, amount, status) 
                         VALUES ('$bookingId', '$referenceId', '$phone', '$amount', 'PENDING')");

    echo json_encode(['status_code' => $status, 'reference_id' => $referenceId]);
}

?>