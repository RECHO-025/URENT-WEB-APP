
<?php
$a = session_id();

if ($a == '')
{ 
session_start();
// create a session 
// store the current time
$now = time();

// get the time the session should have expired
$limit = $now - 60 * 300;

// check the time of the last activity
if (isset ($_SESSION['last_activity']) &&
        $_SESSION['last_activity'] < $limit) {
  // if too old, clear the session array and redirect
  $_SESSION = array();
  ?>
  <p align="center"> Logged Session has expired. Logg in again</p>
  <?php
  include 'index.php';
  exit;
} else {
  // otherwise, set the value to the current time
  $_SESSION['last_activity'] = $now;
}

    }
	else {
	
if($a == $_SESSION['username'])
  {
?> 
<p align="center"> User of the same User name already logged in. Try again </p>
<?php 
include 'index.php';
   }
  else{
  $_SESSION['last_activity'] = $now;
}
  }
?>
