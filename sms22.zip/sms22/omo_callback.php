<?php
// momo_callback.php
// Basic webhook handler. Validate payload and persist to DB.

$raw = file_get_contents('php://input');
file_put_contents(__DIR__.'/momo_callback.log', date('c') . " - " . $raw . PHP_EOL, FILE_APPEND);

header('Content-Type: application/json');
// Respond 200 quickly to acknowledge receipt.
http_response_code(200);
echo json_encode(['status' => 'received']);
exit;

?>