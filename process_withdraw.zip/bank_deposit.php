<?php
// bank_deposit.php
header("Content-Type: text/html; charset=UTF-8");

// === OPTIONAL includes (for DB, logging, or signing) ===
// include 'signnn2.php';
// include 'collect_data.php';

// === YoPayments credentials ===
$api_url  = "https://paymentsapi1.yo.co.ug/ybs/task.php"; // Replace with your actual API endpoint
$api_user = "100615770361";  // Replace with your real API Username
$api_pass = "Tdww-wvR3-ECQ8-gPbZ-Ai3u-VQ7n-3TFU-2bPm";   // Replace with your real API Password

// === COLLECT FORM DATA ===
$RequestTrackingId  = trim($_POST['RequestTrackingId'] ?? uniqid("REQ_"));
$TotalDepositAmount = trim($_POST['TotalDepositAmount'] ?? '');
$Narrative          = trim($_POST['Narrative'] ?? '');
$CurrencyCodes      = $_POST['CurrencyCode'] ?? [];
$Amounts            = $_POST['Amount'] ?? [];

// === HANDLE FILE UPLOAD ===
$fileName = '';
$fileBase64 = '';

if (!empty($_FILES['BankTransferFileContentBase64']['tmp_name'])) {
    $fileTmpPath = $_FILES['BankTransferFileContentBase64']['tmp_name'];
    $fileName = basename($_FILES['BankTransferFileContentBase64']['name']);
    $fileData = file_get_contents($fileTmpPath);
    $fileBase64 = base64_encode($fileData);
}

// === BUILD CurrencyAllocation XML ===
$currencyXml = "";
for ($i = 0; $i < count($CurrencyCodes); $i++) {
    $code = trim($CurrencyCodes[$i]);
    $amt  = trim($Amounts[$i]);
    if ($code !== '' && $amt !== '') {
        $currencyXml .= "
        <CurrencyAllocation>
          <CurrencyCode>{$code}</CurrencyCode>
          <Amount>{$amt}</Amount>
        </CurrencyAllocation>";
    }
}

// === BUILD XML REQUEST ===
$xmlRequest = <<<XML
<?xml version="1.0" encoding="UTF-8"?>
<AutoCreate>
  <Request>
    <APIUsername>{$api_user}</APIUsername>
    <APIPassword>{$api_pass}</APIPassword>
    <Method>acsubmitbankdeposit</Method>
    <RequestTrackingId>{$RequestTrackingId}</RequestTrackingId>
    <TotalDepositAmount>{$TotalDepositAmount}</TotalDepositAmount>
    <Narrative>{$Narrative}</Narrative>
    <BankTransferFileName>{$fileName}</BankTransferFileName>
    <BankTransferFileContentBase64>{$fileBase64}</BankTransferFileContentBase64>
    <AmountBreakDown>
      {$currencyXml}
    </AmountBreakDown>
  </Request>
</AutoCreate>
XML;
?>
<?php
// === SEND XML VIA CURL ===
$ch = curl_init($api_url);
curl_setopt_array($ch, [
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => $xmlRequest,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_HTTPHEADER => [
        "Content-Type: application/xml",
        "Accept: application/xml"
    ],
    CURLOPT_TIMEOUT => 60,
    CURLOPT_SSL_VERIFYPEER => false,
    CURLOPT_SSL_VERIFYHOST => false
]);

$response = curl_exec($ch);
if (curl_errno($ch)) {
    $error = curl_error($ch);
    curl_close($ch);
    die("<h3 style='color:red;'>Connection error:</h3><pre>$error</pre>");
}
curl_close($ch);

// === DISPLAY REQUEST & RESPONSE ===
echo "<h2>XML Sent:</h2><pre>" . htmlspecialchars($xmlRequest) . "</pre>";
echo "<h2>Response Received:</h2><pre>" . htmlspecialchars($response) . "</pre>";

// === PARSE RESPONSE (Optional) ===
$xmlResponse = @simplexml_load_string($response);
if ($xmlResponse === false) {
    echo "<p style='color:red;'>Invalid XML response received.</p>";
} else {
    echo "<h3>Parsed Response:</h3><pre>";
    print_r($xmlResponse);
    echo "</pre>";
}
?>
